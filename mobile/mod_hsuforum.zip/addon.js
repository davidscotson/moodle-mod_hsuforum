angular.module('mm.addons.mod_hsuforum', [])
.constant('mmaModHsuforumDiscPerPage', 10)
.constant('mmaModHsuforumComponent', 'mmaModHsuforum')
.constant('mmaModHsuforumNewDiscussionEvent', 'mma-mod_hsuforum_new_discussion')
.constant('mmaModHsuforumReplyDiscussionEvent', 'mma-mod_hsuforum_reply_discussion')
.constant('mmaModHsuforumAutomSyncedEvent', 'mma-mod_hsuforum_autom_synced')
.constant('mmaModHsuforumManualSyncedEvent', 'mma-mod_hsuforum_manual_synced')
.constant('mmaModHsuforumSyncTime', 300000)
.config(["$stateProvider", function($stateProvider) {
    $stateProvider
    .state('site.mod_hsuforum', {
        url: '/mod_hsuforum',
        params: {
            module: null,
            courseid: null
        },
        views: {
            'site': {
                controller: 'mmaModHsuforumDiscussionsCtrl',
                templateUrl: '$ADDONPATH$/templates/discussions.html'
            }
        }
    })
    .state('site.mod_hsuforum-discussion', {
        url: '/mod_hsuforum-discussion',
        params: {
            discussionid: null,
            cid: null,
            forumid: null,
            cmid: null
        },
        views: {
            'site': {
                controller: 'mmaModHsuforumDiscussionCtrl',
                templateUrl: '$ADDONPATH$/templates/discussion.html'
            }
        }
    })
    .state('site.mod_hsuforum-newdiscussion', {
        url: '/mod_hsuforum-newdiscussion',
        params: {
            cid: null,
            forumid: null,
            cmid: null,
            timecreated: null
        },
        views: {
            'site': {
                controller: 'mmaModHsuforumNewDiscussionCtrl',
                templateUrl: '$ADDONPATH$/templates/newdiscussion.html'
            }
        }
    });
}])
.config(["$mmCourseDelegateProvider", "$mmContentLinksDelegateProvider", "$mmCoursePrefetchDelegateProvider", function($mmCourseDelegateProvider, $mmContentLinksDelegateProvider, $mmCoursePrefetchDelegateProvider) {
    $mmCourseDelegateProvider.registerContentHandler('mmaModHsuforum', 'hsuforum', '$mmaModHsuforumHandlers.courseContent');
    $mmContentLinksDelegateProvider.registerLinkHandler('mmaModHsuforum', '$mmaModHsuforumHandlers.linksHandler');
    $mmCoursePrefetchDelegateProvider.registerPrefetchHandler('mmaModHsuforum', 'hsuforum', '$mmaModHsuforumPrefetchHandler');
}])
.run(["$mmCronDelegate", function($mmCronDelegate) {
    $mmCronDelegate.register('mmaModHsuforum', '$mmaModHsuforumHandlers.syncHandler');
}]);

angular.module('mm.addons.mod_hsuforum')
.controller('mmaModHsuforumDiscussionCtrl', ["$q", "$scope", "$stateParams", "$mmaModHsuforum", "$mmSite", "$mmUtil", "$translate", "$mmEvents", "$ionicScrollDelegate", "mmaModHsuforumComponent", "mmaModHsuforumReplyDiscussionEvent", "$mmaModHsuforumOffline", "$mmaModHsuforumSync", "mmaModHsuforumAutomSyncedEvent", "mmaModHsuforumManualSyncedEvent", "$mmApp", "$ionicPlatform", "mmCoreEventOnlineStatusChanged", function($q, $scope, $stateParams, $mmaModHsuforum, $mmSite, $mmUtil, $translate, $mmEvents,
            $ionicScrollDelegate, mmaModHsuforumComponent, mmaModHsuforumReplyDiscussionEvent, $mmaModHsuforumOffline, $mmaModHsuforumSync,
            mmaModHsuforumAutomSyncedEvent, mmaModHsuforumManualSyncedEvent, $mmApp, $ionicPlatform, mmCoreEventOnlineStatusChanged) {
    var discussionId = $stateParams.discussionid,
        courseid = $stateParams.cid,
        forumId = $stateParams.forumid,
        cmid = $stateParams.cmid,
        scrollView,
        syncObserver, syncManualObserver, onlineObserver;
    $scope.discussionId = discussionId;
    $scope.component = mmaModHsuforumComponent;
    $scope.discussionStr = $translate.instant('discussion');
    $scope.componentId = cmid;
    $scope.courseid = courseid;
    $scope.refreshPostsIcon = 'spinner';
    $scope.syncIcon = 'spinner';
    $scope.newpost = {
        replyingto: undefined,
        editing: undefined,
        subject: '',
        text: '',
        isEditing: false
    };
    $scope.sort = {
        icon: 'ion-arrow-up-c',
        direction: 'ASC',
        text: $translate.instant('mma.mod_hsuforum.sortnewestfirst')
    };
    function fetchPosts(sync, showErrors) {
        var syncPromise,
            onlinePosts = [],
            offlineReplies = [];
        $scope.isOnline = $mmApp.isOnline();
        $scope.isTablet = $ionicPlatform.isTablet();
        if (sync) {
            syncPromise = syncDiscussion(showErrors).catch(function() {
            });
        } else {
            syncPromise = $q.when();
        }
        return syncPromise.then(function() {
            return $mmaModHsuforum.getDiscussionPosts(discussionId).then(function(posts) {
                onlinePosts = posts;
            }).finally(function() {
                return $mmaModHsuforumOffline.hasDiscussionReplies(discussionId).then(function(hasOffline) {
                    $scope.postHasOffline = hasOffline;
                    if (hasOffline) {
                        return $mmaModHsuforumOffline.getDiscussionReplies(discussionId).then(function(replies) {
                            var convertPromises = [];
                            var posts = {};
                            angular.forEach(onlinePosts, function(post) {
                                posts[post.id] = post;
                            });
                            angular.forEach(replies, function(offlineReply) {
                                convertPromises.push($mmaModHsuforumOffline.convertOfflineReplyToOnline(offlineReply)
                                        .then(function(reply) {
                                    offlineReplies.push(reply);
                                    posts[reply.parent].canreply = false;
                                }));
                            });
                            return $q.all(convertPromises).then(function() {
                                onlinePosts = Object.keys(posts).map(function (key) {return posts[key];});
                            });
                        });
                    }
                });
            });
        }).finally(function() {
            var posts = offlineReplies.concat(onlinePosts);
            $scope.discussion = $mmaModHsuforum.extractStartingPost(posts);
            $scope.posts = $mmaModHsuforum.sortDiscussionPosts(posts, $scope.sort.direction);
            return $translate('mma.mod_hsuforum.re').then(function(strReplyPrefix) {
                $scope.defaultSubject = strReplyPrefix + ' ' + $scope.discussion.subject;
                $scope.newpost.subject = $scope.defaultSubject;
            });
        }).catch(function(message) {
            $mmUtil.showErrorModal(message);
            return $q.reject();
        }).finally(function() {
            $scope.discussionLoaded = true;
            $scope.refreshPostsIcon = 'ion-refresh';
            $scope.syncIcon = 'ion-loop';
        });
    }
    $scope.changeSort = function(init) {
        $scope.discussionLoaded = false;
        if (!init) {
            $scope.sort.direction = $scope.sort.direction == 'ASC' ? 'DESC' : 'ASC';
        }
        return fetchPosts(init).then(function() {
            if ($scope.sort.direction == 'ASC') {
                $scope.sort.icon = 'ion-arrow-up-c';
                $scope.sort.text = $translate.instant('mma.mod_hsuforum.sortnewestfirst');
            } else {
                $scope.sort.icon = 'ion-arrow-down-c';
                $scope.sort.text = $translate.instant('mma.mod_hsuforum.sortoldestfirst');
            }
        });
    };
    function syncDiscussion(showErrors) {
        return $mmaModHsuforumSync.syncDiscussionReplies(discussionId).then(function(result) {
            if (result.warnings && result.warnings.length) {
                $mmUtil.showErrorModal(result.warnings[0]);
            }
            if (result && result.updated) {
                $mmEvents.trigger(mmaModHsuforumManualSyncedEvent, {
                    siteid: $mmSite.getId(),
                    forumid: forumId,
                    userid: $mmSite.getUserId(),
                    warnings: result.warnings
                });
            }
            return result.updated;
        }).catch(function(error) {
            if (showErrors) {
                if (error) {
                    $mmUtil.showErrorModal(error);
                } else {
                    $mmUtil.showErrorModal('mm.core.errorsync', true);
                }
            }
            return $q.reject();
        });
    }
    function refreshPosts(sync, showErrors) {
        scrollTop();
        $scope.refreshPostsIcon = 'spinner';
        $scope.syncIcon = 'spinner';
        return $mmaModHsuforum.invalidateDiscussionPosts(discussionId).finally(function() {
            return fetchPosts(sync, showErrors);
        });
    }
    function notifyPostListChanged() {
        var data = {
            forumid: forumId,
            discussionid: discussionId,
            cmid: cmid
        };
        $mmEvents.trigger(mmaModHsuforumReplyDiscussionEvent, data);
    }
    $scope.changeSort(true).then(function() {
        $mmSite.write('mod_hsuforum_view_forum_discussion', {
            discussionid: discussionId
        });
    });
    $scope.refreshPosts = function(showErrors) {
        if ($scope.discussionLoaded) {
            return refreshPosts(true, showErrors).finally(function() {
                $scope.$broadcast('scroll.refreshComplete');
            });
        }
    };
    syncObserver = $mmEvents.on(mmaModHsuforumAutomSyncedEvent, function(data) {
        if (data && data.siteid == $mmSite.getId() && data.forumid == forumId && data.userid == $mmSite.getUserId() &&
                discussionId == data.discussionid) {
            $scope.discussionLoaded = false;
            refreshPosts(false);
        }
    });
    onlineObserver = $mmEvents.on(mmCoreEventOnlineStatusChanged, function(online) {
        $scope.isOnline = online;
    });
    syncManualObserver = $mmEvents.on(mmaModHsuforumManualSyncedEvent, function(data) {
        if (data && data.siteid == $mmSite.getId() && data.forumid == forumId && data.userid == $mmSite.getUserId()) {
            $scope.discussionLoaded = false;
            refreshPosts(false);
        }
    });
    function scrollTop() {
        if (!scrollView) {
            scrollView = $ionicScrollDelegate.$getByHandle('mmaModHsuforumPostsScroll');
        }
        scrollView && scrollView.scrollTop && scrollView.scrollTop();
    }
    $scope.postListChanged = function() {
        $scope.newpost.replyingto = undefined;
        $scope.newpost.editing = undefined;
        $scope.newpost.subject = $scope.defaultSubject;
        $scope.newpost.text = '';
        $scope.newpost.isEditing = false;
        notifyPostListChanged();
        $scope.discussionLoaded = false;
        refreshPosts(false).finally(function() {
            $scope.discussionLoaded = true;
        });
    };
    $scope.$on('$destroy', function(){
        syncObserver && syncObserver.off && syncObserver.off();
        syncManualObserver && syncManualObserver.off && syncManualObserver.off();
        onlineObserver && onlineObserver.off && onlineObserver.off();
    });
}]);

angular.module('mm.addons.mod_hsuforum')
.controller('mmaModHsuforumDiscussionsCtrl', ["$q", "$scope", "$stateParams", "$mmaModHsuforum", "$mmCourse", "$mmUtil", "$mmGroups", "$mmUser", "$mmEvents", "$ionicScrollDelegate", "$ionicPlatform", "mmUserProfileState", "mmaModHsuforumNewDiscussionEvent", "$mmSite", "$translate", "mmaModHsuforumReplyDiscussionEvent", "$mmText", "mmaModHsuforumComponent", "$mmaModHsuforumOffline", "$mmaModHsuforumSync", "$mmEvents", "mmaModHsuforumAutomSyncedEvent", "mmaModHsuforumManualSyncedEvent", "$mmApp", "mmCoreEventOnlineStatusChanged", function($q, $scope, $stateParams, $mmaModHsuforum, $mmCourse, $mmUtil, $mmGroups, $mmUser,
            $mmEvents, $ionicScrollDelegate, $ionicPlatform, mmUserProfileState, mmaModHsuforumNewDiscussionEvent, $mmSite, $translate,
            mmaModHsuforumReplyDiscussionEvent, $mmText, mmaModHsuforumComponent, $mmaModHsuforumOffline, $mmaModHsuforumSync, $mmEvents,
            mmaModHsuforumAutomSyncedEvent, mmaModHsuforumManualSyncedEvent, $mmApp, mmCoreEventOnlineStatusChanged) {
    var module = $stateParams.module || {},
        courseid = $stateParams.courseid,
        forum,
        page = 0,
        scrollView,
        shouldScrollTop = false,
        usesGroups = false,
        obsNewDisc, obsReply, syncObserver, syncManualObserver, onlineObserver;
    $scope.title = module.name;
    $scope.description = module.description;
    $scope.moduleUrl = module.url;
    $scope.moduleName = $mmCourse.translateModuleName('hsuforum');
    $scope.courseid = courseid;
    $scope.userStateName = mmUserProfileState;
    $scope.isCreateEnabled = $mmaModHsuforum.isCreateDiscussionEnabled();
    $scope.refreshIcon = 'spinner';
    $scope.syncIcon = 'spinner';
    $scope.component = mmaModHsuforumComponent;
    $scope.componentId = module.id;
    function fetchForumDataAndDiscussions(refresh, sync, showErrors) {
        $scope.isOnline = $mmApp.isOnline();
        return $mmaModHsuforum.getForum(courseid, module.id).then(function(forumdata) {
            forum = forumdata;
            $scope.title = forum.name || $scope.title;
            $scope.description = forum.intro || $scope.description;
            $scope.forum = forum;
            if (sync) {
                return syncForum(showErrors).catch(function() {
                });
            }
        }).then(function() {
            return $mmGroups.getActivityGroupMode(forum.cmid).then(function(mode) {
                usesGroups = mode === $mmGroups.SEPARATEGROUPS || mode === $mmGroups.VISIBLEGROUPS;
            }).finally(function() {
                var promises = [];
                promises.push($mmaModHsuforumOffline.hasNewDiscussions(forum.id).then(function(hasOffline) {
                    $scope.hasOffline = hasOffline;
                    if (hasOffline) {
                        return $mmaModHsuforumOffline.getNewDiscussions(forum.id).then(function(offlineDiscussions) {
                            var promise = usesGroups ?
                                $mmaModHsuforum.formatDiscussionsGroups(forum.cmid, offlineDiscussions) : $q.when(offlineDiscussions);
                            return promise.then(function(offlineDiscussions) {
                                var userPromises = [];
                                angular.forEach(offlineDiscussions, function(discussion) {
                                    userPromises.push($mmUser.getProfile(discussion.userid, courseid, true).then(function(user) {
                                        discussion.userfullname = user.fullname;
                                        discussion.userpictureurl = user.profileimageurl;
                                    }));
                                });
                                return $q.all(userPromises).then(function() {
                                    $scope.offlineDiscussions = offlineDiscussions;
                                });
                            });
                        });
                    } else {
                        $scope.offlineDiscussions = [];
                    }
                }));
                promises.push(fetchDiscussions(refresh));
                return $q.all(promises);
            });
        }).catch(function(message) {
            if (!refresh) {
                return refreshData(sync);
            }
            if (message) {
                $mmUtil.showErrorModal(message);
            } else {
                $mmUtil.showErrorModal('mma.mod_hsuforum.errorgetforum', true);
            }
            $scope.canLoadMore = false;
            return $q.reject();
        });
    }
    function fetchDiscussions(refresh) {
        if (refresh) {
            page = 0;
        }
        return $mmaModHsuforum.getDiscussions(forum.id, page).then(function(response) {
            var promise = usesGroups ?
                    $mmaModHsuforum.formatDiscussionsGroups(forum.cmid, response.discussions) : $q.when(response.discussions);
            return promise.then(function(discussions) {
                if (page == 0) {
                    $scope.discussions = discussions;
                } else {
                    $scope.discussions = $scope.discussions.concat(discussions);
                }
                $scope.count = $scope.discussions.length;
                $scope.canLoadMore = response.canLoadMore;
                page++;
                return $mmaModHsuforumOffline.hasForumReplies(forum.id).then(function(hasOffline) {
                    var offlinePromises = [];
                    $scope.hasOffline = $scope.hasOffline || hasOffline;
                    if (hasOffline) {
                        angular.forEach(discussions, function(discussion) {
                            offlinePromises.push($mmaModHsuforumOffline.getDiscussionReplies(discussion.discussion).then(function(replies) {
                                discussion.numreplies = parseInt(discussion.numreplies, 10) + parseInt(replies.length, 10);
                            }));
                        });
                    }
                    return $q.all(offlinePromises);
                });
            });
        }, function(message) {
            $mmUtil.showErrorModal(message);
            $scope.canLoadMore = false;
            return $q.reject();
        });
    }
    function syncForum(showErrors) {
        var promises = [],
            warnings = [];
        promises.push($mmaModHsuforumSync.syncForumDiscussions(forum.id).then(function(result) {
            if (result.warnings && result.warnings.length) {
                warnings = warnings.concat(result.warnings);
                $mmUtil.showErrorModal(result.warnings[0]);
            }
            return result.updated;
        }));
        promises.push($mmaModHsuforumSync.syncForumReplies(forum.id).then(function(result) {
            if (result.warnings && result.warnings.length) {
                warnings = warnings.concat(result.warnings);
                $mmUtil.showErrorModal(result.warnings[0]);
            }
            return result.updated;
        }));
        return $q.all(promises).then(function(results) {
            var updated = results.reduce(function(a, b) {
                return a || b;
            }, false);
            if (updated) {
                $mmEvents.trigger(mmaModHsuforumManualSyncedEvent, {
                    siteid: $mmSite.getId(),
                    forumid: forum.id,
                    userid: $mmSite.getUserId(),
                    warnings: warnings
                });
            }
            return updated;
        }).catch(function(error) {
            if (showErrors) {
                if (error) {
                    $mmUtil.showErrorModal(error);
                } else {
                    $mmUtil.showErrorModal('mm.core.errorsync', true);
                }
            }
            return $q.reject();
        });
    }
    function scrollTop() {
        if (!scrollView) {
            scrollView = $ionicScrollDelegate.$getByHandle('mmaModHsuforumDiscussionsScroll');
        }
        scrollView && scrollView.scrollTop && scrollView.scrollTop();
    }
    function refreshData(sync, showErrors) {
        var promises = [];
        promises.push($mmaModHsuforum.invalidateForumData(courseid));
        if (forum) {
            promises.push($mmaModHsuforum.invalidateDiscussionsList(forum.id));
            promises.push($mmGroups.invalidateActivityGroupMode(forum.cmid));
        }
        return $q.all(promises).finally(function() {
            return fetchForumDataAndDiscussions(true, sync, showErrors);
        });
    }
    function eventReceived(data) {
        if ((forum && forum.id === data.forumid) || data.cmid === module.id) {
            if ($ionicPlatform.isTablet()) {
                scrollTop();
            } else {
                shouldScrollTop = true;
            }
            $scope.discussionsLoaded = false;
            showSpinnerAndFetch(false);
            $mmCourse.checkModuleCompletion(courseid, module.completionstatus);
        }
    }
    fetchForumDataAndDiscussions(false, true).then(function() {
        $mmaModHsuforum.logView(forum.id).then(function() {
            $mmCourse.checkModuleCompletion(courseid, module.completionstatus);
        });
    }).finally(function() {
        $scope.refreshIcon = 'ion-refresh';
        $scope.syncIcon = 'ion-loop';
        $scope.discussionsLoaded = true;
    });
    $scope.loadMoreDiscussions = function() {
        fetchDiscussions().finally(function() {
            $scope.$broadcast('scroll.infiniteScrollComplete');
        });
    };
    $scope.refreshDiscussions = function(showErrors) {
        if ($scope.discussionsLoaded) {
            return showSpinnerAndFetch(true, showErrors);
        }
    };
    function showSpinnerAndFetch(sync, showErrors) {
        $scope.refreshIcon = 'spinner';
        $scope.syncIcon = 'spinner';
        return refreshData(sync, showErrors).finally(function() {
            $scope.discussionsLoaded = true;
            $scope.refreshIcon = 'ion-refresh';
            $scope.syncIcon = 'ion-loop';
            $scope.$broadcast('scroll.refreshComplete');
        });
    }
    $scope.expandDescription = function() {
        $mmText.expandText($translate.instant('mm.core.description'), $scope.description, false, mmaModHsuforumComponent, module.id);
    };
    onlineObserver = $mmEvents.on(mmCoreEventOnlineStatusChanged, function(online) {
        $scope.isOnline = online;
    });
    syncObserver = $mmEvents.on(mmaModHsuforumAutomSyncedEvent, function(data) {
        if (forum && data && data.siteid == $mmSite.getId() && data.forumid == forum.id && data.userid == $mmSite.getUserId()) {
            $scope.discussionsLoaded = false;
            return showSpinnerAndFetch(false);
        }
    });
    syncManualObserver = $mmEvents.on(mmaModHsuforumManualSyncedEvent, function(data) {
        if (data && data.siteid == $mmSite.getId() && data.forumid == forum.id && data.userid == $mmSite.getUserId()) {
            $scope.discussionsLoaded = false;
            return showSpinnerAndFetch(false);
        }
    });
    obsNewDisc = $mmEvents.on(mmaModHsuforumNewDiscussionEvent, eventReceived);
    obsReply = $mmEvents.on(mmaModHsuforumReplyDiscussionEvent, eventReceived);
    $scope.$on('$ionicView.enter', function() {
        if (shouldScrollTop) {
            shouldScrollTop = false;
            scrollTop();
        }
    });
    $scope.$on('$destroy', function(){
        obsNewDisc && obsNewDisc.off && obsNewDisc.off();
        obsReply && obsReply.off && obsReply.off();
        syncObserver && syncObserver.off && syncObserver.off();
        onlineObserver && onlineObserver.off && onlineObserver.off();
    });
}]);

angular.module('mm.addons.mod_hsuforum')
.controller('mmaModHsuforumNewDiscussionCtrl', ["$scope", "$stateParams", "$mmGroups", "$q", "$mmaModHsuforum", "$mmEvents", "$ionicPlatform", "$mmUtil", "$ionicHistory", "$translate", "mmaModHsuforumNewDiscussionEvent", "$mmaModHsuforumOffline", "$mmSite", "mmaModHsuforumComponent", "mmaModHsuforumAutomSyncedEvent", "$mmSyncBlock", "$mmaModHsuforumSync", function($scope, $stateParams, $mmGroups, $q, $mmaModHsuforum, $mmEvents, $ionicPlatform,
            $mmUtil, $ionicHistory, $translate, mmaModHsuforumNewDiscussionEvent, $mmaModHsuforumOffline, $mmSite, mmaModHsuforumComponent,
            mmaModHsuforumAutomSyncedEvent, $mmSyncBlock, $mmaModHsuforumSync) {
    var courseid = $stateParams.cid,
        forumid = $stateParams.forumid,
        cmid = $stateParams.cmid,
        timecreated = $stateParams.timecreated,
        forumName,
        syncObserver,
        syncId;
    $scope.newdiscussion = {
        subject: '',
        text: '',
        subscribe: true
    };
    $scope.hasOffline = false;
    function fetchDiscussionData(refresh) {
        return $mmGroups.getActivityGroupMode(cmid).then(function(mode) {
            var promises = [];
            if (mode === $mmGroups.SEPARATEGROUPS || mode === $mmGroups.VISIBLEGROUPS) {
                promises.push($mmGroups.getActivityAllowedGroups(cmid).then(function(forumgroups) {
                    var promise;
                    if (mode === $mmGroups.VISIBLEGROUPS) {
                        promise = validateVisibleGroups(forumgroups, refresh);
                    } else {
                        promise = $q.when(forumgroups);
                    }
                    return promise.then(function(forumgroups) {
                        if (forumgroups.length > 0) {
                            $scope.groups = forumgroups;
                            $scope.newdiscussion.groupid = $scope.newdiscussion.groupid ?
                                $scope.newdiscussion.groupid : forumgroups[0].id;
                            $scope.showGroups = true;
                        } else {
                            var message = mode === $mmGroups.SEPARATEGROUPS ?
                                                'mma.mod_hsuforum.cannotadddiscussionall' : 'mma.mod_hsuforum.cannotadddiscussion';
                            return $q.reject($translate.instant(message));
                        }
                    });
                }));
            } else {
                $scope.showGroups = false;
            }
            promises.push($mmaModHsuforum.getForum(courseid, cmid).then(function(forum) {
                forumName = forum.name;
            }).catch(function() {
            }));
            if (timecreated && !refresh) {
                syncId = $mmaModHsuforumSync.getForumSyncId(forumid);
                promises.push($mmaModHsuforumSync.waitForSync(syncId).then(function() {
                    if (!$scope.$$destroyed) {
                        $mmSyncBlock.blockOperation(mmaModHsuforumComponent, syncId);
                    }
                    return $mmaModHsuforumOffline.getNewDiscussion(forumid, timecreated).then(function(discussion) {
                        $scope.hasOffline = true;
                        $scope.newdiscussion.groupid = discussion.groupid ? discussion.groupid : $scope.newdiscussion.groupid;
                        $scope.newdiscussion.subject = discussion.subject;
                        $scope.newdiscussion.text = discussion.message;
                        $scope.newdiscussion.subscribe = discussion.subscribe;
                    });
                }));
            }
            return $q.all(promises);
        }).then(function(message) {
            $scope.showForm = true;
        }).catch(function(message) {
            if (message) {
                $mmUtil.showErrorModal(message);
            } else {
                $mmUtil.showErrorModal('mma.mod_hsuforum.errorgetgroups', true);
            }
            $scope.showForm = false;
            return $q.reject();
        });
    }
    function validateVisibleGroups(forumgroups, refresh) {
        if ($mmaModHsuforum.isCanAddDiscussionAvailable()) {
            return $mmaModHsuforum.canAddDiscussionToAll(forumid).catch(function() {
                return false;
            }).then(function(canAdd) {
                if (canAdd) {
                    return forumgroups;
                } else {
                    var promises = [],
                        filtered = [];
                    angular.forEach(forumgroups, function(group) {
                        promises.push($mmaModHsuforum.canAddDiscussion(forumid, group.id).catch(function() {
                            return true;
                        }).then(function(canAdd) {
                            if (canAdd) {
                                filtered.push(group);
                            }
                        }));
                    });
                    return $q.all(promises).then(function() {
                        return filtered;
                    });
                }
            });
        } else {
            return $mmGroups.getUserGroupsInCourse(courseid, refresh).then(function(usergroups) {
                if (usergroups.length === 0) {
                    return forumgroups;
                }
                return filterGroups(forumgroups, usergroups);
            });
        }
    }
    function filterGroups(forumgroups, usergroups) {
        var filtered = [],
            usergroupsids = usergroups.map(function(g) {
                return g.id;
            });
        angular.forEach(forumgroups, function(fg) {
            if (usergroupsids.indexOf(fg.id) > -1) {
                filtered.push(fg);
            }
        });
        return filtered;
    }
    fetchDiscussionData().finally(function() {
        $scope.groupsLoaded = true;
    });
    $scope.refreshGroups = function() {
        var p1 = $mmGroups.invalidateActivityGroupMode(cmid),
            p2 = $mmGroups.invalidateActivityAllowedGroups(cmid),
            p3 = $mmaModHsuforum.invalidateCanAddDiscussion(forumid);
        $q.all([p1, p2, p3]).finally(function() {
            fetchDiscussionData(true).finally(function() {
                $scope.$broadcast('scroll.refreshComplete');
            });
        });
    };
    function returnToDiscussions(discussionid) {
        var data = {
            forumid: forumid,
            cmid: cmid
        };
        if (discussionid) {
            data.discussionid = discussionid;
        }
        $mmEvents.trigger(mmaModHsuforumNewDiscussionEvent, data);
        if ($ionicPlatform.isTablet()) {
            $scope.hasOffline = false;
            $scope.newdiscussion.subject = '';
            $scope.newdiscussion.text = '';
        } else {
            $ionicHistory.goBack();
        }
    }
    $scope.add = function() {
        var subject = $scope.newdiscussion.subject,
            message = $scope.newdiscussion.text,
            subscribe = $scope.newdiscussion.subscribe,
            groupid = $scope.newdiscussion.groupid;
        if (!subject) {
            $mmUtil.showErrorModal('mma.mod_hsuforum.erroremptysubject', true);
            return;
        }
        if (!message) {
            $mmUtil.showErrorModal('mma.mod_hsuforum.erroremptymessage', true);
            return;
        }
        $mmUtil.isRichTextEditorEnabled().then(function(enabled) {
            if (!enabled) {
                if (message.indexOf('<p>') == -1) {
                    message = '<p>' + message + '</p>';
                }
                message = message.replace(/\n/g, '<br>');
            }
            return $mmaModHsuforum.addNewDiscussion(forumid, forumName, courseid, subject, message, subscribe, groupid, undefined,
                timecreated);
        }).then(function(discussionid) {
            returnToDiscussions(discussionid);
        }).catch(function(message) {
            if (message) {
                $mmUtil.showErrorModal(message);
            } else {
                $mmUtil.showErrorModal('mma.mod_hsuforum.cannotcreatediscussion', true);
            }
        });
    };
    if (timecreated) {
        syncObserver = $mmEvents.on(mmaModHsuforumAutomSyncedEvent, function(data) {
            if (data && data.siteid == $mmSite.getId() && data.forumid == forumid && data.userid == $mmSite.getUserId()) {
                $mmUtil.showModal('mm.core.notice', 'mm.core.contenteditingsynced');
                returnToDiscussions();
            }
        });
    }
    $scope.discard = function() {
        return $mmUtil.showConfirm($translate('mm.core.areyousure')).then(function() {
            return $mmaModHsuforumOffline.deleteNewDiscussion(forumid, timecreated).then(function() {
                returnToDiscussions();
            });
        });
    };
    $scope.$on('$destroy', function(){
        syncObserver && syncObserver.off && syncObserver.off();
        if (syncId) {
            $mmSyncBlock.unblockOperation(mmaModHsuforumComponent, syncId);
        }
    });
}]);

angular.module('mm.addons.mod_hsuforum')
.directive('mmaModHsuforumDiscussionPost', ["$mmaModHsuforum", "$mmUtil", "$translate", "$q", "$mmaModHsuforumOffline", "$mmSyncBlock", "mmaModHsuforumComponent", "$mmaModHsuforumSync", function($mmaModHsuforum, $mmUtil, $translate, $q, $mmaModHsuforumOffline, $mmSyncBlock,
        mmaModHsuforumComponent, $mmaModHsuforumSync) {
    return {
        restrict: 'E',
        scope: {
            post: '=',
            courseid: '=',
            discussionId: '=',
            title: '=',
            subject: '=',
            component: '=',
            componentId: '=',
            newpost: '=',
            showdivider: '=?',
            titleimportant: '=?',
            onpostchange: '&?',
            defaultsubject: '=?',
            scrollHandle: '@?'
        },
        templateUrl: '$ADDONPATH$/templates/discussionpost.html',
        transclude: true,
        link: function(scope) {
            var syncId;
            scope.isReplyEnabled = $mmaModHsuforum.isReplyPostEnabled();
            scope.uniqueid = scope.post.id ? 'reply' + scope.post.id : 'edit' + scope.post.parent;
            scope.showReply = function() {
                scope.newpost.replyingto = scope.post.id;
                scope.newpost.editing = 'reply' + scope.post.id;
                scope.newpost.isEditing = false;
                scope.newpost.subject = scope.defaultsubject || '';
                scope.newpost.text = '';
            };
            scope.editReply = function() {
                syncId = $mmaModHsuforumSync.getDiscussionSyncId(scope.discussionId);
                $mmSyncBlock.blockOperation(mmaModHsuforumComponent, syncId);
                scope.newpost.replyingto = scope.post.parent;
                scope.newpost.editing = 'edit' + scope.post.parent;
                scope.newpost.isEditing = true;
                scope.newpost.subject = scope.post.subject;
                scope.newpost.text = scope.post.message;
            };
            scope.reply = function() {
                if (!scope.newpost.subject) {
                    $mmUtil.showErrorModal('mma.mod_hsuforum.erroremptysubject', true);
                    return;
                }
                if (!scope.newpost.text) {
                    $mmUtil.showErrorModal('mma.mod_hsuforum.erroremptymessage', true);
                    return;
                }
                var message = scope.newpost.text,
                    modal = $mmUtil.showModalLoading('mm.core.sending', true);
                $mmUtil.isRichTextEditorEnabled().then(function(enabled) {
                    if (!enabled) {
                        if (message.indexOf('<p>') == -1) {
                            message = '<p>' + message + '</p>';
                        }
                        message = message.replace(/\n/g, '<br>');
                    }
                    return $mmaModHsuforum.getForum(scope.courseid, scope.componentId).then(function(forum) {
                        return $mmaModHsuforum.replyPost(scope.newpost.replyingto, scope.discussionId, forum.id, forum.name,
                                scope.courseid, scope.newpost.subject, message).then(function() {
                            if (scope.onpostchange) {
                                scope.onpostchange();
                            }
                        });
                    }).catch(function(message) {
                        if (message) {
                            $mmUtil.showErrorModal(message);
                        } else {
                            $mmUtil.showErrorModal('mma.mod_hsuforum.couldnotadd', true);
                        }
                    });
                }).finally(function() {
                    modal.dismiss();
                    if (syncId) {
                        $mmSyncBlock.unblockOperation(mmaModHsuforumComponent, syncId);
                    }
                });
            };
            scope.cancel = function() {
                var promise;
                if ((!scope.newpost.subject || scope.newpost.subject == scope.defaultsubject) && !scope.newpost.text) {
                    promise = $q.when();
                } else {
                    promise = $mmUtil.showConfirm($translate('mm.core.areyousure'));
                }
                promise.then(function() {
                    scope.newpost.replyingto = undefined;
                    scope.newpost.editing = undefined;
                    scope.newpost.subject = scope.defaultsubject || '';
                    scope.newpost.text = '';
                    scope.newpost.isEditing = false;
                });
                if (syncId) {
                    $mmSyncBlock.unblockOperation(mmaModHsuforumComponent, syncId);
                }
            };
            scope.discard = function() {
                $mmUtil.showConfirm($translate('mm.core.areyousure')).then(function() {
                    return $mmaModHsuforumOffline.deleteReply(scope.post.parent).finally(function() {
                        scope.newpost.replyingto = undefined;
                        scope.newpost.editing = undefined;
                        scope.newpost.subject = scope.defaultsubject || '';
                        scope.newpost.text = '';
                        scope.newpost.isEditing = false;
                        if (scope.onpostchange) {
                            scope.onpostchange();
                        }
                    });
                });
                if (syncId) {
                    $mmSyncBlock.unblockOperation(mmaModHsuforumComponent, syncId);
                }
            };
            scope.$on('$destroy', function(){
                if (syncId) {
                    $mmSyncBlock.unblockOperation(mmaModHsuforumComponent, syncId);
                }
            });
        }
    };
}]);

angular.module('mm.addons.mod_hsuforum')
.factory('$mmaModHsuforumHandlers', ["$mmCourse", "$mmaModHsuforum", "$state", "$mmUtil", "$mmContentLinksHelper", "$q", "$mmEvents", "$mmSite", "$mmaModHsuforumPrefetchHandler", "$mmCoursePrefetchDelegate", "mmCoreDownloading", "mmCoreNotDownloaded", "mmCoreOutdated", "mmaModHsuforumComponent", "mmCoreEventPackageStatusChanged", "$mmaModHsuforumSync", function($mmCourse, $mmaModHsuforum, $state, $mmUtil, $mmContentLinksHelper, $q, $mmEvents, $mmSite,
            $mmaModHsuforumPrefetchHandler, $mmCoursePrefetchDelegate, mmCoreDownloading, mmCoreNotDownloaded, mmCoreOutdated,
            mmaModHsuforumComponent, mmCoreEventPackageStatusChanged, $mmaModHsuforumSync) {
    var self = {};
        self.courseContent = function() {
        var self = {};
                self.isEnabled = function() {
            return $mmaModHsuforum.isPluginEnabled();
        };
                self.getController = function(module, courseId) {
            return function($scope) {
                var downloadBtn = {
                        hidden: true,
                        icon: 'ion-ios-cloud-download-outline',
                        label: 'mm.core.download',
                        action: function(e) {
                            if (e) {
                                e.preventDefault();
                                e.stopPropagation();
                            }
                            download();
                        }
                    },
                    refreshBtn = {
                        hidden: true,
                        icon: 'ion-android-refresh',
                        label: 'mm.core.refresh',
                        action: function(e) {
                            if (e) {
                                e.preventDefault();
                                e.stopPropagation();
                            }
                            $scope.spinner = true;
                            $mmaModHsuforum.invalidateContent(module.id, courseId).finally(function() {
                                download();
                            });
                        }
                    };
                $scope.title = module.name;
                $scope.icon = $mmCourse.getModuleIconSrc('hsuforum');
                $scope.class = 'mma-mod_hsuforum-handler';
                $scope.buttons = [downloadBtn, refreshBtn];
                $scope.spinner = true;
                $scope.action = function(e) {
                    if (e) {
                        e.preventDefault();
                        e.stopPropagation();
                    }
                    $state.go('site.mod_hsuforum', {module: module, courseid: courseId});
                };
                function download() {
                    $scope.spinner = true;
                    $mmaModHsuforumPrefetchHandler.getDownloadSize(module, courseId).then(function(size) {
                        $mmUtil.confirmDownloadSize(size).then(function() {
                            $mmaModHsuforumPrefetchHandler.prefetch(module, courseId).catch(function() {
                                if (!$scope.$$destroyed) {
                                    $mmUtil.showErrorModal('mm.core.errordownloading', true);
                                }
                            });
                        }).catch(function() {
                            $scope.spinner = false;
                        });
                    }).catch(function(error) {
                        $scope.spinner = false;
                        if (error) {
                            $mmUtil.showErrorModal(error);
                        } else {
                            $mmUtil.showErrorModal('mm.core.errordownloading', true);
                        }
                    });
                }
                function showStatus(status) {
                    if (status) {
                        $scope.spinner = status === mmCoreDownloading;
                        downloadBtn.hidden = status !== mmCoreNotDownloaded;
                        refreshBtn.hidden = status !== mmCoreOutdated;
                    }
                }
                var statusObserver = $mmEvents.on(mmCoreEventPackageStatusChanged, function(data) {
                    if (data.siteid === $mmSite.getId() && data.componentId === module.id &&
                            data.component === mmaModHsuforumComponent) {
                        showStatus(data.status);
                    }
                });
                $mmCoursePrefetchDelegate.getModuleStatus(module, courseId).then(showStatus);
                $scope.$on('$destroy', function() {
                    statusObserver && statusObserver.off && statusObserver.off();
                });
            };
        };
        return self;
    };
        self.linksHandler = function() {
        var self = {},
            patterns = ['/mod/hsuforum/view.php', '/mod/hsuforum/discuss.php'];
                function isIndexEnabled(siteId, courseId) {
            return $mmaModHsuforum.isPluginEnabled(siteId).then(function(enabled) {
                if (!enabled) {
                    return false;
                }
                return courseId || $mmCourse.canGetModuleWithoutCourseId(siteId);
            });
        }
                function isDiscEnabled(siteId) {
            return $mmaModHsuforum.isPluginEnabled(siteId);
        }
                self.getActions = function(siteIds, url, courseId) {
            if (url.indexOf(patterns[0]) > -1) {
                return $mmContentLinksHelper.treatModuleIndexUrl(siteIds, url, isIndexEnabled, courseId);
            } else if (url.indexOf(patterns[1]) > -1) {
                var params = $mmUtil.extractUrlParams(url);
                if (params.d != 'undefined') {
                    courseId = courseId || params.courseid || params.cid;
                    return $mmContentLinksHelper.filterSupportedSites(siteIds, isDiscEnabled, false, courseId).then(function(ids) {
                        if (!ids.length) {
                            return [];
                        } else {
                            return [{
                                message: 'mm.core.view',
                                icon: 'ion-eye',
                                sites: ids,
                                action: function(siteId) {
                                    var stateParams = {
                                        discussionid: parseInt(params.d, 10),
                                        cid: courseId
                                    };
                                    $mmContentLinksHelper.goInSite('site.mod_hsuforum-discussion', stateParams, siteId);
                                }
                            }];
                        }
                    });
                }
            }
            return $q.when([]);
        };
                self.handles = function(url) {
            for (var i = 0; i < patterns.length; i++) {
                var position = url.indexOf(patterns[i]);
                if (position > -1) {
                    return url.substr(0, position);
                }
            }
        };
        return self;
    };
        self.syncHandler = function() {
        var self = {};
                self.execute = function(siteId) {
            return $mmaModHsuforumSync.syncAllForums(siteId);
        };
                self.getInterval = function() {
            return 600000;
        };
                self.isSync = function() {
            return true;
        };
                self.usesNetwork = function() {
            return true;
        };
        return self;
    };
    return self;
}]);

angular.module('mm.addons.mod_hsuforum')
.factory('$mmaModHsuforum', ["$q", "$mmSite", "$mmUser", "$mmGroups", "$translate", "$mmSitesManager", "mmaModHsuforumDiscPerPage", "mmaModHsuforumComponent", "$mmaModHsuforumOffline", "$mmApp", "$mmUtil", function($q, $mmSite, $mmUser, $mmGroups, $translate, $mmSitesManager, mmaModHsuforumDiscPerPage,
            mmaModHsuforumComponent, $mmaModHsuforumOffline, $mmApp, $mmUtil) {
    var self = {};
        function getCanAddDiscussionCacheKey(forumid, groupid) {
        return getCommonCanAddDiscussionCacheKey(forumid) + ':' + groupid;
    }
        function getCommonCanAddDiscussionCacheKey(forumid) {
        return 'mmaModHsuforum:canadddiscussion:' + forumid;
    }
        function getForumDataCacheKey(courseid) {
        return 'mmaModHsuforum:forum:' + courseid;
    }
        function getDiscussionPostsCacheKey(discussionid) {
        return 'mmaModHsuforum:discussion:' + discussionid;
    }
        function getDiscussionsListCacheKey(forumid) {
        return 'mmaModHsuforum:discussions:' + forumid;
    }
        self.addNewDiscussion = function(forumId, name, courseId, subject, message, subscribe, groupId, siteId, timecreated) {
        siteId = siteId || $mmSite.getId();
        var discardPromise = timecreated ? $mmaModHsuforumOffline.deleteNewDiscussion(forumId, timecreated, siteId) : $q.when();
        return discardPromise.then(function() {
            if (!$mmApp.isOnline()) {
                return storeOffline();
            }
            return self.addNewDiscussionOnline(forumId, subject, message, subscribe, groupId, siteId).then(function() {
                return true;
            }).catch(function(error) {
                if (error && error.wserror) {
                    return $q.reject(error.error);
                } else {
                    return storeOffline();
                }
            });
        });
        function storeOffline() {
            return $mmaModHsuforumOffline.addNewDiscussion(forumId, name, courseId, subject, message, subscribe, groupId, siteId)
                    .then(function() {
                return false;
            });
        }
    };
        self.addNewDiscussionOnline = function(forumId, subject, message, subscribe, groupId, siteId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            var params = {
                forumid: forumId,
                subject: subject,
                message: message,
                options: [
                    {
                        name: 'discussionsubscribe',
                        value: !!subscribe
                    }
                ]
            };
            if (groupId) {
                params.groupid = groupId;
            }
            return site.write('mod_hsuforum_add_discussion', params).catch(function(error) {
                return $q.reject({
                    error: error,
                    wserror: $mmUtil.isWebServiceError(error)
                });
            }).then(function(response) {
                if (!response || !response.discussionid) {
                    return $q.reject({
                        wserror: true
                    });
                } else {
                    return response.discussionid;
                }
            });
        });
    };
        self.canAddDiscussion = function(forumid, groupid) {
        var params = {
                forumid: forumid,
                groupid: groupid
            },
            preSets = {
                cacheKey: getCanAddDiscussionCacheKey(forumid, groupid)
            };
        return $mmSite.read('mod_hsuforum_can_add_discussion', params, preSets).then(function(result) {
            if (result) {
                return !!result.status;
            }
            return $q.reject();
        });
    };
        self.canAddDiscussionToAll = function(forumid) {
        return self.canAddDiscussion(forumid, -1);
    };
        self.extractStartingPost = function(posts) {
        for (var i = posts.length - 1; i >= 0; i--) {
            if (posts[i].parent == 0) {
                return posts.splice(i, 1).pop();
            }
        }
        return undefined;
    };
        self.isCanAddDiscussionAvailable = function() {
        return $mmSite.wsAvailable('mod_hsuforum_can_add_discussion');
    };
        self.isPluginEnabled = function(siteId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            return  site.wsAvailable('mod_hsuforum_get_forums_by_courses') &&
                    site.wsAvailable('mod_hsuforum_get_forum_discussions_paginated') &&
                    site.wsAvailable('mod_hsuforum_get_forum_discussion_posts');
        });
    };
        self.formatDiscussionsGroups = function(cmid, discussions) {
        discussions = angular.copy(discussions);
        return $translate('mm.core.allparticipants').then(function(strAllParts) {
            return $mmGroups.getActivityAllowedGroups(cmid).then(function(forumgroups) {
                var groups = {};
                angular.forEach(forumgroups, function(fg) {
                    groups[fg.id] = fg;
                });
                angular.forEach(discussions, function(disc) {
                    if (disc.groupid === -1) {
                        disc.groupname = strAllParts;
                    } else {
                        var group = groups[disc.groupid];
                        if (group) {
                            disc.groupname = group.name;
                        }
                    }
                });
                return discussions;
            });
        }).catch(function() {
            return discussions;
        });
    };
        self.getForum = function(courseId, cmId, siteId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            var params = {
                    courseids: [courseId]
                },
                preSets = {
                    cacheKey: getForumDataCacheKey(courseId)
                };
            return site.read('mod_hsuforum_get_forums_by_courses', params, preSets).then(function(forums) {
                for (var x in forums) {
                    if (forums[x].cmid == cmId) {
                        return forums[x];
                    }
                }
                return $q.reject();
            });
        });
    };
        self.getDiscussionPosts = function(discussionid) {
        var params = {
                discussionid: discussionid
            },
            preSets = {
                cacheKey: getDiscussionPostsCacheKey(discussionid)
            };
        return $mmSite.read('mod_hsuforum_get_forum_discussion_posts', params, preSets).then(function(response) {
            if (response) {
                storeUserData(response.posts);
                return response.posts;
            } else {
                return $q.reject();
            }
        });
    };
        self.sortDiscussionPosts = function(posts, direction) {
        return posts.sort(function (a, b) {
            a = parseInt(a.created, 10);
            b = parseInt(b.created, 10);
            if (direction == 'ASC') {
                return a >= b ? 1 : -1;
            } else {
                return a <= b ? 1 : -1;
            }
        });
    };
        self.getDiscussions = function(forumId, page, forceCache, siteId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            page = page || 0;
            var params = {
                    forumid: forumId,
                    sortby:  'timemodified',
                    sortdirection:  'DESC',
                    page: page,
                    perpage: mmaModHsuforumDiscPerPage
                },
                preSets = {
                    cacheKey: getDiscussionsListCacheKey(forumId)
                };
            if (forceCache) {
                preSets.omitExpires = true;
            }
            return site.read('mod_hsuforum_get_forum_discussions_paginated', params, preSets).then(function(response) {
                if (response) {
                    var canLoadMore = response.discussions.length >= mmaModHsuforumDiscPerPage;
                    storeUserData(response.discussions);
                    return {discussions: response.discussions, canLoadMore: canLoadMore};
                } else {
                    return $q.reject();
                }
            });
        });
    };
        self.getDiscussionsInPages = function(forumId, forceCache, numPages, startPage, siteId) {
        if (typeof numPages == 'undefined') {
            numPages = -1;
        }
        startPage = startPage || 0;
        numPages = parseInt(numPages, 10);
        var result = {
            discussions: [],
            error: false
        };
        if (!numPages) {
            return result;
        }
        return getPage(startPage);
        function getPage(page) {
            return self.getDiscussions(forumId, page, forceCache, siteId).then(function(response) {
                result.discussions = result.discussions.concat(response.discussions);
                numPages--;
                if (response.canLoadMore && numPages !== 0) {
                    return getPage(page + 1);
                } else {
                    return result;
                }
            }).catch(function() {
                result.error = true;
                return result;
            });
        }
    };
        self.invalidateCanAddDiscussion = function(forumId, siteId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            return site.invalidateWsCacheForKeyStartingWith(getCommonCanAddDiscussionCacheKey(forumId));
        });
    };
        self.invalidateContent = function(moduleId, courseId) {
        return self.getForum(courseId, moduleId).then(function(forum) {
            return self.getDiscussionsInPages(forum.id, true).then(function(response) {
                var promises = [];
                promises.push(self.invalidateForumData(courseId));
                promises.push(self.invalidateDiscussionsList(forum.id));
                promises.push(self.invalidateCanAddDiscussion(forum.id));
                angular.forEach(response.discussions, function(discussion) {
                    promises.push(self.invalidateDiscussionPosts(discussion.discussion));
                });
                return $q.all(promises);
            });
        });
    };
        self.invalidateDiscussionPosts = function(discussionId, siteId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            return site.invalidateWsCacheForKey(getDiscussionPostsCacheKey(discussionId));
        });
    };
        self.invalidateDiscussionsList = function(forumId, siteId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            return site.invalidateWsCacheForKey(getDiscussionsListCacheKey(forumId));
        });
    };
        self.invalidateFiles = function(moduleId) {
        return $mmFilepool.invalidateFilesByComponent($mmSite.getId(), mmaModHsuforumComponent, moduleId);
    };
        self.invalidateForumData = function(courseid) {
        return $mmSite.invalidateWsCacheForKey(getForumDataCacheKey(courseid));
    };
        self.isCreateDiscussionEnabled = function() {
        return $mmSite.wsAvailable('core_group_get_activity_groupmode') &&
                $mmSite.wsAvailable('core_group_get_activity_allowed_groups') &&
                $mmSite.wsAvailable('mod_hsuforum_add_discussion');
    };
        self.isReplyPostEnabled = function() {
        return $mmSite.wsAvailable('mod_hsuforum_add_discussion_post');
    };
        self.logView = function(id) {
        if (id) {
            var params = {
                forumid: id
            };
            return $mmSite.write('mod_hsuforum_view_forum', params);
        }
        return $q.reject();
    };
        self.replyPost = function(postId, discussionId, forumId, name, courseId, subject, message, siteId) {
        siteId = siteId || $mmSite.getId();
        if (!$mmApp.isOnline()) {
            return storeOffline();
        }
        return $mmaModHsuforumOffline.deleteReply(postId, siteId).then(function() {
            return self.replyPostOnline(postId, subject, message, siteId).then(function() {
                return true;
            }).catch(function(error) {
                if (error && error.wserror) {
                    return $q.reject(error.error);
                } else {
                    return storeOffline();
                }
            });
        });
        function storeOffline() {
            return $mmaModHsuforumOffline.replyPost(postId, discussionId, forumId, name, courseId, subject, message, siteId)
                    .then(function() {
                return false;
            });
        }
    };
        self.replyPostOnline = function(postId, subject, message, siteId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            var params = {
                postid: postId,
                subject: subject,
                message: message
            };
            return site.write('mod_hsuforum_add_discussion_post', params).catch(function(error) {
                return $q.reject({
                    error: error,
                    wserror: $mmUtil.isWebServiceError(error)
                });
            }).then(function(response) {
                if (!response || !response.postid) {
                    return $q.reject({
                        wserror: true
                    });
                } else {
                    return response.postid;
                }
            });
        });
    };
        function storeUserData(list) {
        var ids = [];
        angular.forEach(list, function(entry) {
            var id = parseInt(entry.userid);
            if (!isNaN(id) && ids.indexOf(id) === -1) {
                ids.push(id);
                $mmUser.storeUser(id, entry.userfullname, entry.userpictureurl);
            }
            if (typeof entry.usermodified != 'undefined') {
                id = parseInt(entry.usermodified);
                if(!isNaN(id) && ids.indexOf(id) === -1) {
                    ids.push(id);
                    $mmUser.storeUser(id, entry.usermodifiedfullname, entry.usermodifiedpictureurl);
                }
            }
        });
    }
    return self;
}]);

angular.module('mm.addons.mod_hsuforum')
.constant('mmaModHsuforumOfflineDiscussionsStore', 'mma_mod_hsuforum_offline_discussions')
.constant('mmaModHsuforumOfflineRepliesStore', 'mma_mod_hsuforum_offline_replies')
.config(["$mmSitesFactoryProvider", "mmaModHsuforumOfflineDiscussionsStore", "mmaModHsuforumOfflineRepliesStore", function($mmSitesFactoryProvider, mmaModHsuforumOfflineDiscussionsStore, mmaModHsuforumOfflineRepliesStore) {
    var stores = [
        {
            name: mmaModHsuforumOfflineDiscussionsStore,
            keyPath: ['forumid', 'userid', 'timecreated'],
            indexes: [
                {
                    name: 'forumid'
                },
                {
                    name: 'courseid'
                },
                {
                    name: 'userid'
                },
                {
                    name: 'timecreated'
                },
                {
                    name: 'forumAndUser',
                    generator: function(obj) {
                        return [obj.forumid, obj.userid];
                    }
                }
            ]
        },
        {
            name: mmaModHsuforumOfflineRepliesStore,
            keyPath: ['postid', 'userid'],
            indexes: [
                {
                    name: 'postid'
                },
                {
                    name: 'courseid'
                },
                {
                    name: 'userid'
                },
                {
                    name: 'timecreated'
                },
                {
                    name: 'discussionAndUser',
                    generator: function(obj) {
                        return [obj.discussionid, obj.userid];
                    }
                },
                {
                    name: 'forumAndUser',
                    generator: function(obj) {
                        return [obj.forumid, obj.userid];
                    }
                }
            ]
        }
    ];
    $mmSitesFactoryProvider.registerStores(stores);
}])
.factory('$mmaModHsuforumOffline', ["$log", "mmaModHsuforumOfflineDiscussionsStore", "$mmSitesManager", "mmaModHsuforumOfflineRepliesStore", "$mmSite", "$mmUser", function($log, mmaModHsuforumOfflineDiscussionsStore, $mmSitesManager, mmaModHsuforumOfflineRepliesStore,
        $mmSite, $mmUser) {
    $log = $log.getInstance('$mmaModHsuforumOffline');
    var self = {};
        self.deleteNewDiscussion = function(forumId, timecreated, siteId, userId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            userId = userId || site.getUserId();
            return site.getDb().remove(mmaModHsuforumOfflineDiscussionsStore, [forumId, userId, timecreated]);
        });
    };
        self.getNewDiscussion = function(forumId, timecreated, siteId, userId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            userId = userId || site.getUserId();
            return site.getDb().get(mmaModHsuforumOfflineDiscussionsStore, [forumId, userId, timecreated]);
        });
    };
        self.getAllNewDiscussions = function(siteId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            return site.getDb().getAll(mmaModHsuforumOfflineDiscussionsStore);
        });
    };
        self.hasNewDiscussions = function(forumId, siteId, userId) {
        return self.getNewDiscussions(forumId, siteId, userId).then(function(discussions) {
            return !!discussions.length;
        }).catch(function() {
            return false;
        });
    };
        self.getNewDiscussions = function(forumId, siteId, userId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            userId = userId || site.getUserId();
            return site.getDb().whereEqual(mmaModHsuforumOfflineDiscussionsStore, 'forumAndUser', [forumId, userId]);
        });
    };
        self.addNewDiscussion = function(forumId, name, courseId, subject, message, subscribe, groupId, siteId, userId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            userId = userId || site.getUserId();
            var db = site.getDb(),
                entry = {
                    forumid: forumId,
                    name: name,
                    courseid: courseId,
                    subject: subject,
                    message: message,
                    subscribe: subscribe,
                    groupid: groupId || -1,
                    userid: userId,
                    timecreated: new Date().getTime()
                };
            return db.insert(mmaModHsuforumOfflineDiscussionsStore, entry);
        });
    };
        self.deleteReply = function(postId, siteId, userId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            userId = userId || site.getUserId();
            return site.getDb().remove(mmaModHsuforumOfflineRepliesStore, [postId, userId]);
        });
    };
        self.getAllReplies = function(siteId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            return site.getDb().getAll(mmaModHsuforumOfflineRepliesStore);
        });
    };
        self.hasForumReplies = function(forumId, siteId, userId) {
        return self.getForumReplies(forumId, siteId, userId).then(function(replies) {
            return !!replies.length;
        }).catch(function() {
            return false;
        });
    };
        self.getForumReplies = function(forumId, siteId, userId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            userId = userId || site.getUserId();
            return site.getDb().whereEqual(mmaModHsuforumOfflineRepliesStore, 'forumAndUser', [forumId, userId]);
        });
    };
        self.hasDiscussionReplies = function(discussionId, siteId, userId) {
        return self.getDiscussionReplies(discussionId, siteId, userId).then(function(replies) {
            return !!replies.length;
        }).catch(function() {
            return false;
        });
    };
        self.getDiscussionReplies = function(discussionId, siteId, userId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            userId = userId || site.getUserId();
            return site.getDb().whereEqual(mmaModHsuforumOfflineRepliesStore, 'discussionAndUser', [discussionId, userId]);
        });
    };
        self.convertOfflineReplyToOnline = function(offlineReply) {
        var reply = {
            attachment: "",
            canreply: false,
            children: [],
            created: offlineReply.timecreated,
            discussion: offlineReply.discussionid,
            id: false,
            mailed: 0,
            mailnow: 0,
            message: offlineReply.message,
            messageformat: 1,
            messagetrust: 0,
            modified: false,
            parent: offlineReply.postid,
            postread: false,
            subject: offlineReply.subject,
            totalscore: 0,
            userid: offlineReply.userid
        };
        return $mmUser.getProfile(offlineReply.userid, offlineReply.courseid, true).then(function(user) {
            reply.userfullname = user.fullname;
            reply.userpictureurl = user.profileimageurl;
        }).catch(function() {
        }).then(function() {
            return reply;
        });
    };
        self.replyPost = function(postId, discussionId, forumId, name, courseId, subject, message, siteId, userId) {
        siteId = siteId || $mmSite.getId();
        return $mmSitesManager.getSite(siteId).then(function(site) {
            userId = userId || site.getUserId();
            var db = site.getDb(),
                discussion = {
                    postid: postId,
                    discussionid: discussionId,
                    forumid: forumId,
                    name: name,
                    courseid: courseId,
                    subject: subject,
                    message: message,
                    userid: userId,
                    timecreated: new Date().getTime()
                };
            return db.insert(mmaModHsuforumOfflineRepliesStore, discussion);
        });
    };
    return self;
}]);

angular.module('mm.addons.mod_hsuforum')
.factory('$mmaModHsuforumSync', ["$q", "$log", "$mmApp", "$mmSitesManager", "$mmaModHsuforumOffline", "$mmSite", "$mmEvents", "$mmSync", "$mmLang", "mmaModHsuforumComponent", "$mmaModHsuforum", "$translate", "mmaModHsuforumAutomSyncedEvent", "mmaModHsuforumSyncTime", "$mmCourse", "$mmSyncBlock", function($q, $log, $mmApp, $mmSitesManager, $mmaModHsuforumOffline, $mmSite, $mmEvents, $mmSync, $mmLang,
        mmaModHsuforumComponent, $mmaModHsuforum, $translate, mmaModHsuforumAutomSyncedEvent, mmaModHsuforumSyncTime, $mmCourse, $mmSyncBlock) {
    $log = $log.getInstance('$mmaModHsuforumSync');
    var self = $mmSync.createChild(mmaModHsuforumComponent, mmaModHsuforumSyncTime);
        self.syncAllForums = function(siteId) {
        if (!$mmApp.isOnline()) {
            $log.debug('Cannot sync all forums because device is offline.');
            return $q.reject();
        }
        var promise;
        if (!siteId) {
            $log.debug('Try to sync forums in all sites.');
            promise = $mmSitesManager.getSitesIds();
        } else {
            $log.debug('Try to sync forums in site ' + siteId);
            promise = $q.when([siteId]);
        }
        return promise.then(function(siteIds) {
            var sitePromises = [];
            angular.forEach(siteIds, function(siteId) {
                sitePromises.push($mmaModHsuforumOffline.getAllNewDiscussions(siteId).then(function(discussions) {
                    var promises = {};
                    for (var i in discussions) {
                        var discussion = discussions[i];
                        if (typeof promises[discussion.forumid] != 'undefined') {
                            continue;
                        }
                        promises[discussion.forumid] = self.syncForumDiscussionsIfNeeded(discussion.forumid, discussion.userid, siteId)
                                .then(function(result) {
                            if (result && result.updated) {
                                $mmEvents.trigger(mmaModHsuforumAutomSyncedEvent, {
                                    siteid: siteId,
                                    forumid: discussion.forumid,
                                    userid: discussion.userid,
                                    warnings: result.warnings
                                });
                            }
                        });
                    }
                    promises = Object.keys(promises).map(function (key) {return promises[key];});
                    return $q.all(promises);
                }));
                sitePromises.push($mmaModHsuforumOffline.getAllReplies(siteId).then(function(replies) {
                    var promises = {};
                    for (var i in replies) {
                        var reply = replies[i];
                        if (typeof promises[reply.discussionid] != 'undefined') {
                            continue;
                        }
                        promises[reply.discussionid] = self.syncDiscussionRepliesIfNeeded(reply.discussionid, reply.userid, siteId)
                                .then(function(result) {
                            if (result && result.updated) {
                                $mmEvents.trigger(mmaModHsuforumAutomSyncedEvent, {
                                    siteid: siteId,
                                    forumid: reply.forumid,
                                    discussionid: reply.discussionid,
                                    userid: reply.userid,
                                    warnings: result.warnings
                                });
                            }
                        });
                    }
                    promises = Object.keys(promises).map(function (key) {return promises[key];});
                    return $q.all(promises);
                }));
            });
            return $q.all(sitePromises);
        });
    };
        self.syncForumDiscussionsIfNeeded = function(forumId, userId, siteId) {
        siteId = siteId || $mmSite.getId();
        var syncId = self.getForumSyncId(forumId, userId);
        return self.isSyncNeeded(syncId, siteId).then(function(needed) {
            if (needed) {
                return self.syncForumDiscussions(forumId, userId, siteId);
            }
        });
    };
        self.syncForumDiscussions = function(forumId, userId, siteId) {
        userId = userId || $mmSite.getUserId();
        siteId = siteId || $mmSite.getId();
        var syncPromise,
            courseId,
            syncId = self.getForumSyncId(forumId, userId),
            result = {
                warnings: [],
                updated: false
            };
        if (self.isSyncing(syncId, siteId)) {
            return self.getOngoingSync(syncId, siteId);
        }
        if ($mmSyncBlock.isBlocked(mmaModHsuforumComponent, syncId, siteId)) {
            $log.debug('Cannot sync forum ' + forumId + ' because it is blocked.');
            var modulename = $mmCourse.translateModuleName('hsuforum');
            return $mmLang.translateAndReject('mm.core.errorsyncblocked', {$a: modulename});
        }
        $log.debug('Try to sync forum ' + forumId + ' for user ' + userId);
        syncPromise = $mmaModHsuforumOffline.getNewDiscussions(forumId, siteId, userId).catch(function() {
            return [];
        }).then(function(discussions) {
            if (!discussions.length) {
                return;
            } else if (!$mmApp.isOnline()) {
                return $q.reject();
            }
            var promises = [];
            angular.forEach(discussions, function(data) {
                var promise;
                courseId = data.courseid;
                promise = $mmaModHsuforum.addNewDiscussionOnline(forumId, data.subject, data.message, data.subscribe, data.groupid,
                    siteId);
                promises.push(promise.then(function() {
                    result.updated = true;
                    return $mmaModHsuforumOffline.deleteNewDiscussion(forumId, data.timecreated, siteId, userId);
                }).catch(function(error) {
                    if (error && error.wserror) {
                        result.updated = true;
                        return $mmaModHsuforumOffline.deleteNewDiscussion(forumId, data.timecreated, siteId, userId).then(function() {
                            result.warnings.push($translate.instant('mm.core.warningofflinedatadeleted', {
                                component: $mmCourse.translateModuleName('hsuforum'),
                                name: data.name,
                                error: error.error
                            }));
                        });
                    } else {
                        return $q.reject(error && error.error);
                    }
                }));
            });
            return $q.all(promises);
        }).then(function() {
            var promises = [];
            promises.push($mmaModHsuforum.invalidateDiscussionsList(forumId, siteId));
            promises.push($mmaModHsuforum.invalidateCanAddDiscussion(forumId, siteId));
            return $q.all(promises).catch(function() {
            });
        }).then(function() {
            return self.setSyncTime(syncId, siteId).catch(function() {
            });
        }).then(function() {
            return result;
        });
        return self.addOngoingSync(syncId, syncPromise, siteId);
    };
        self.syncForumReplies = function(forumId, userId, siteId) {
        return $mmaModHsuforumOffline.getForumReplies(forumId, siteId, userId).catch(function() {
            return {};
        }).then(function(replies) {
            if (!replies.length) {
                return { warnings: [], updated: false };
            } else if (!$mmApp.isOnline()) {
                return $q.reject();
            }
            var promises = {};
            for (var i in replies) {
                var reply = replies[i];
                if (typeof promises[reply.discussionid] != 'undefined') {
                    continue;
                }
                promises[reply.discussionid] = self.syncDiscussionReplies(reply.discussionid, userId, siteId);
            }
            promises = Object.keys(promises).map(function (key) {return promises[key];});
            return $q.all(promises).then(function(results) {
                return results.reduce(function(a, b) {
                    a.warnings = a.warnings.concat(b.warnings);
                    a.updated = a.updated || b.updated;
                    return a;
                }, { warnings: [], updated: false });
            });
        });
    };
        self.syncDiscussionRepliesIfNeeded = function(discussionId, userId, siteId) {
        siteId = siteId || $mmSite.getId();
        var syncId = self.getDiscussionSyncId(discussionId, userId);
        return self.isSyncNeeded(syncId, siteId).then(function(needed) {
            if (needed) {
                return self.syncDiscussionReplies(discussionId, userId, siteId);
            }
        });
    };
        self.syncDiscussionReplies = function(discussionId, userId, siteId) {
        userId = userId || $mmSite.getUserId();
        siteId = siteId || $mmSite.getId();
        var syncPromise,
            courseId,
            forumId,
            syncId = self.getDiscussionSyncId(discussionId, userId),
            result = {
                warnings: [],
                updated: false
            };
        if (self.isSyncing(syncId, siteId)) {
            return self.getOngoingSync(syncId, siteId);
        }
        if ($mmSyncBlock.isBlocked(this.component, syncId, siteId)) {
            $log.debug('Cannot sync forum discussion ' + discussionId + ' because it is blocked.');
            var modulename = $mmCourse.translateModuleName('hsuforum');
            return $mmLang.translateAndReject('mm.core.errorsyncblocked', {$a: modulename});
        }
        $log.debug('Try to sync forum discussion ' + discussionId + ' for user ' + userId);
        syncPromise = $mmaModHsuforumOffline.getDiscussionReplies(discussionId, siteId, userId).catch(function() {
            return [];
        }).then(function(replies) {
            if (!replies.length) {
                return;
            } else if (!$mmApp.isOnline()) {
                return $q.reject();
            }
            var promises = [];
            angular.forEach(replies, function(data) {
                var promise;
                courseId = data.courseid;
                forumId = data.forumid;
                promise = $mmaModHsuforum.replyPostOnline(data.postid, data.subject, data.message, siteId);
                promises.push(promise.then(function() {
                    result.updated = true;
                    return $mmaModHsuforumOffline.deleteReply(data.postid, siteId, userId);
                }).catch(function(error) {
                    if (error && error.wserror) {
                        result.updated = true;
                        return $mmaModHsuforumOffline.deleteReply(data.postid, siteId, userId).then(function() {
                            result.warnings.push($translate.instant('mm.core.warningofflinedatadeleted', {
                                component: $mmCourse.translateModuleName('hsuforum'),
                                name: data.name,
                                error: error.error
                            }));
                        });
                    } else {
                        return $q.reject(error && error.error);
                    }
                }));
            });
            return $q.all(promises);
        }).then(function() {
            var promises = [];
            if (forumId) {
                promises.push($mmaModHsuforum.invalidateDiscussionsList(forumId, siteId));
            }
            promises.push($mmaModHsuforum.invalidateDiscussionPosts(discussionId, siteId));
            return $q.all(promises).catch(function() {
            });
        }).then(function() {
            return self.setSyncTime(syncId, siteId).catch(function() {
            });
        }).then(function() {
            return result;
        });
        return self.addOngoingSync(syncId, syncPromise, siteId);
    };
        self.getForumSyncId = function(forumId, userId) {
        userId = userId || $mmSite.getUserId();
        return 'hsuforum#' + forumId + '#' + userId;
    };
        self.getDiscussionSyncId = function(discussionId, userId) {
        userId = userId || $mmSite.getUserId();
        return 'discussion#' + discussionId + '#' + userId;
    };
    return self;
}]);

angular.module('mm.addons.mod_hsuforum')
.factory('$mmaModHsuforumPrefetchHandler', ["$mmaModHsuforum", "mmaModHsuforumComponent", "$mmFilepool", "$mmSite", "$q", "$mmUtil", "$mmUser", "$mmGroups", "md5", "$mmPrefetchFactory", function($mmaModHsuforum, mmaModHsuforumComponent, $mmFilepool, $mmSite, $q, $mmUtil, $mmUser,
            $mmGroups, md5, $mmPrefetchFactory) {
    var self = $mmPrefetchFactory.createPrefetchHandler(mmaModHsuforumComponent);
        self.download = function(module, courseId) {
        return self.prefetch(module, courseId);
    };
        self.getFiles = function(module, courseId) {
        var files;
        return $mmaModHsuforum.getForum(courseId, module.id).then(function(forum) {
            files = self.getIntroFilesFromInstance(module, forum);
            return getPostsForPrefetch(forum.id);
        }).then(function(posts) {
            return files.concat(getPostsFiles(posts));
        }).catch(function() {
            return [];
        });
    };
        function getPostsFiles(posts) {
        var files = [];
        angular.forEach(posts, function(post) {
            if (post.attachments && post.attachments.length) {
                files = files.concat(post.attachments);
            }
            if (post.message) {
                files = files.concat($mmUtil.extractDownloadableFilesFromHtmlAsFakeFileObjects(post.message));
            }
        });
        return files;
    }
        function getPostsForPrefetch(forumId) {
        return $mmaModHsuforum.getDiscussionsInPages(forumId, false, 2).then(function(response) {
            if (response.error) {
                return $q.reject();
            }
            var promises = [],
                posts = [];
            angular.forEach(response.discussions, function(discussion) {
                promises.push($mmaModHsuforum.getDiscussionPosts(discussion.discussion).then(function(ps) {
                    posts = posts.concat(ps);
                }));
            });
            return $q.all(promises).then(function() {
                return posts;
            });
        });
    }
        self.getRevision = function(module, courseId) {
        return $mmaModHsuforum.getForum(courseId, module.id).then(function(forum) {
            return getRevisionFromForum(forum);
        });
    };
        function getRevisionFromForum(forum) {
        var revision = '' + forum.numdiscussions;
        if (typeof forum.introfiles == 'undefined' && forum.intro) {
            var urls = $mmUtil.extractDownloadableFilesFromHtml(forum.intro);
            urls = urls.sort(function (a, b) {
                return a > b;
            });
            return revision + '#' + md5.createHash(JSON.stringify(urls));
        }
        return revision;
    }
        self.getTimemodified = function(module, courseId) {
        return $mmaModHsuforum.getForum(courseId, module.id).then(function(forum) {
            return getTimemodifiedFromForum(module, forum, false);
        });
    };
        function getTimemodifiedFromForum(module, forum, getRealTime) {
        var timemodified = forum.timemodified || 0,
            siteId = $mmSite.getId(),
            introFiles = self.getIntroFilesFromInstance(module, forum);
        timemodified = Math.max(timemodified, $mmFilepool.getTimemodifiedFromFileList(introFiles));
        if (getRealTime) {
            return getTimemodifiedFromDiscussions();
        }
        return $mmFilepool.getPackageRevision(siteId, self.component, module.id).catch(function() {
            return '';
        }).then(function(revision) {
            revision = '' + revision;
            revision = revision.split('#')[0];
            if (parseInt(revision, 10) != forum.numdiscussions) {
                return $mmUtil.timestamp();
            }
            return getTimemodifiedFromDiscussions();
        });
        function getTimemodifiedFromDiscussions() {
            return $mmaModHsuforum.getDiscussions(forum.id, 0).then(function(response) {
                if (response.discussions && response.discussions[0]) {
                    var discussionTime =  parseInt(response.discussions[0].timemodified, 10);
                    if (!isNaN(discussionTime)) {
                        timemodified = Math.max(timemodified, discussionTime);
                    }
                }
                return timemodified;
            });
        }
    }
        self.invalidateContent = function(moduleId, courseId) {
        return $mmaModHsuforum.invalidateContent(moduleId, courseId);
    };
        self.invalidateModule = function(module, courseId) {
        return $mmaModHsuforum.getForum(courseId, module.id).then(function(forum) {
            var promises = [];
            promises.push($mmaModHsuforum.invalidateForumData(courseId));
            promises.push($mmaModHsuforum.invalidateDiscussionsList(forum.id));
            return $q.all(promises);
        });
    };
        self.isEnabled = function() {
        return $mmaModHsuforum.isPluginEnabled();
    };
        self.prefetch = function(module, courseId, single) {
        return self.prefetchPackage(module, courseId, single, prefetchForum);
    };
        function prefetchForum(module, courseId, single, siteId) {
        var revision,
            timemod,
            forum;
        return $mmaModHsuforum.getForum(courseId, module.id).then(function(f) {
            forum = f;
            revision = getRevisionFromForum(forum);
            return getTimemodifiedFromForum(module, forum, true);
        }).then(function(time) {
            timemod = time;
            return getPostsForPrefetch(forum.id);
        }).then(function(posts) {
            var promises = [],
                files = self.getIntroFilesFromInstance(module, forum),
                userIds = [],
                canCreateDiscussions = $mmaModHsuforum.isCreateDiscussionEnabled() && forum.cancreatediscussions;
            files = files.concat(getPostsFiles(posts));
            angular.forEach(posts, function(post) {
                if (userIds.indexOf(post.userid) == -1) {
                    userIds.push(post.userid);
                    promises.push($mmUser.getProfile(post.userid, courseId));
                    if (post.userpictureurl) {
                        promises.push($mmFilepool.addToQueueByUrl(siteId, post.userpictureurl).catch(function() {
                        }));
                    }
                }
            });
            angular.forEach(files, function(file) {
                promises.push($mmFilepool.addToQueueByUrl(siteId, file.fileurl, self.component, module.id, file.timemodified));
            });
            promises.push(prefetchGroupsInfo(forum, courseId, canCreateDiscussions));
            return $q.all(promises);
        }).then(function() {
            return {
                revision: revision,
                timemod: timemod
            };
        });
    }
        function prefetchGroupsInfo(forum, courseId, canCreateDiscussions) {
        return $mmGroups.getActivityGroupMode(forum.cmid).then(function(mode) {
            if (mode !== $mmGroups.SEPARATEGROUPS && mode !== $mmGroups.VISIBLEGROUPS) {
                return;
            }
            return $mmGroups.getActivityAllowedGroups(forum.cmid).then(function(groups) {
                if (mode === $mmGroups.SEPARATEGROUPS) {
                    return;
                }
                if (canCreateDiscussions) {
                    if ($mmaModHsuforum.isCanAddDiscussionAvailable()) {
                        return $mmaModHsuforum.canAddDiscussionToAll(forum.id).catch(function() {
                            return false;
                        }).then(function(canAdd) {
                            if (canAdd) {
                                return;
                            }
                            var groupPromises = [];
                            angular.forEach(groups, function(group) {
                                groupPromises.push($mmaModHsuforum.canAddDiscussion(forum.id, group.id).catch(function() {
                                }));
                            });
                            return $q.all(groupPromises);
                        });
                    } else {
                        return $mmGroups.getUserGroupsInCourse(courseId, true);
                    }
                }
            });
        }, function(error) {
            if (canCreateDiscussions) {
                return $q.reject(error);
            }
        });
    }
    return self;
}]);
